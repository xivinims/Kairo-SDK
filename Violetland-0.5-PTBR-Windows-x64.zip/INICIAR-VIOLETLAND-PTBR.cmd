@echo off
cd /d "%~dp0"
set LANG=pt_BR.UTF-8
set LANGUAGE=pt_BR
violetland.exe
